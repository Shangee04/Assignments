from pydantic import BaseModel
from pymongo import MongoClient
from main import app_main
from schemas.models import Item

client = MongoClient("mongodb://intern_23:intern%40123@192.168.0.220:2717/interns_b2_23")
db = client.interns_b2_23
inventory = db.Shangeetha


@app_main.get("/")
def welcome():
    return {"Welcome to Inventory"}


@app_main.get("/get_all")
def get_all(items_list):
    items = (items_list.find())
    new_item = []
    for new_item in items:
        del items["_id"]
        new_item.append(items)
    return new_item


@app_main.post("/items/{item_id}")
def create_item(item_id: int, item: Item):
    db[item_id] = (item.dict())
    inventory.insert_one(item.dict())
    return db


@app_main.put("/Welcome/{name}")
def update_item(name: str, upd: Item):
    inventory.update_one({"name": name}, {"$set": upd.dict()})
    return "updated"


@app_main.delete("/items/{items_id}")
def delete_item(item_id: int):
    inventory.delete_one({"items_id": item_id})
    return {
        "db": db
    }
