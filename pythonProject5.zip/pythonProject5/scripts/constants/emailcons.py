class Email_constants:
    sender_email = "shangeetha.jayakumar456@gmail.com"
    sender_password = "nlhthxusvmidukwv"


email_obj = Email_constants()
