import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel

from scripts.core.services.service_item import item_router
from utility.mong_utility import inventory

app = FastAPI()
app.include_router(item_router)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)


#class Item(BaseModel):
#    name: str
#    quantity: int
#    cost: int
#    tax_price: float


#@app.get("/")
#def read_item():
#    return {"Welcome to Inventory"}

#@app.get("/get_all")
#async def get_all():
#    items = (inventory.find())
#    new_item = []
#    for product in items:
#        del product["id"]
#        new_item.append(product)
#    return new_item

#@app.post("/items/{item_id}")
#def create_item(item_id: int, item: Item):
#    inventory.insert_one(item.dict())
#    return {"created"}


#@app.put("/Welcome/{name}")
#def update_item(name: str, upd: Item):
#    inventory.update_one({"name": name}, {"$set": upd.dict()})
#    return {"updated"}


#@app.delete("/items/{name}")
#def delete_item(name: str):
#    inventory.delete_one({"name": name})
#    return {"deleted"}
