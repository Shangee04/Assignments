class Item_ends:
    get_items = "/get_all"
    create_items = "/items/{item_id}"
    update_items = "/Welcome/{name}"
    delete_items = "/items/{name}"
    get_Total_price = "/Total_price"
    send_email = "/send_email"




