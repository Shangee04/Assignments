from fastapi import APIRouter
from schemas.models import Item, Email
from scripts.core.handlers.Item_handler import read_item, get_all, create_item, update_item, delete_item, \
    pipeline_aggregate
from scripts.core.handlers.email_handler import send_email

app = APIRouter()


@app.get("/")
def fun():
    return read_item()


@app.get("/get_all")
def fun():
    return get_all()


@app.post("/items/{item_id}")
def fun(item: Item):
    return create_item(item)


@app.put("/Welcome/{name}")
def fun(name: str, upd: Item):
    return update_item(name, upd)


@app.delete("/items/{name}")
def fun(name: str):
    return delete_item(name)


@app.get("/Total_price")
def fun():
    return pipeline_aggregate()


@app.post("/send_email")
def fun(email: Email):
    return send_email(email)
