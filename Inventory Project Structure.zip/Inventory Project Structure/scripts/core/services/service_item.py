from fastapi import APIRouter

from scripts.core.DB.MongoDB import Item
from scripts.core.handlers.Item_handler import Item_handler

item_router = APIRouter()
item_object = Item_handler


@item_router.get("/")
def get_all():
    all_item = item_object.get_data()
    return all_item


@item_router.post("/items/")
def create_data(item: Item):
    all_item = item_object.create_data(item)
    return all_item


@item_router.put("/items/{item_id}")
def update_data(name: str,upd: Item):
    all_item = item_object.update_data(name)
    return all_item


item_router.delete("/items/{item_id}")
def delete_date(item_id: int):
    all_item = item_object.delete_data()
    return all_item
