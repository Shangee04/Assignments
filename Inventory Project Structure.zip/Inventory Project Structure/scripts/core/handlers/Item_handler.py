from main import Item
from scripts.core.DB.MongoDB import update_item, create_item, read_item , delete_item



class Item_handler():


    def get_all(self):
        return read_item()

    def post_data(self,item_id: int, item: Item):
        return create_item(item_id)

    def put_data(self,name: str, upd: Item):
        return update_item(name)

    def delete_data(self,item_id: int):
        return delete_item(item_id)
