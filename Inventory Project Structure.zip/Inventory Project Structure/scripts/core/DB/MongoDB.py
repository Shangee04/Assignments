from pydantic import BaseModel
from pymongo import MongoClient

from main import app

client = MongoClient("mongodb://intern_23:intern%40123@192.168.0.220:2717/interns_b2_23")
db = client.interns_b2_23
inventory = db.Shangeetha


class Item(BaseModel):
    name: str
    quantity: int
    cost: int
    tax_price: float


@app.get("/")
def welcome():
    return {"Welcome to Inventory"}


@app.get("/get_all")
def get_all(items_list):
    items = (items_list.find())
    new_item = []
    for new_item in items:
        delete_item["id"]
        new_item.append(items)
        return new_item


@app.post("/items/{item_id}")
def create_item(item_id: int, item: Item):
    db[item_id] = (item.dict())
    inventory.insert_one(item.dict())
    return db


@app.put("/Welcome/{name}")
def update_item(name: str, upd: Item):
    inventory.update_one({"name": name}, {"$set": upd.dict()})
    return "updated"


@app.delete("/items/{items_id}")
def delete_item(item_id: int):
    inventory.delete_one({"items_id": item_id})
    return {
        "db": db
    }

