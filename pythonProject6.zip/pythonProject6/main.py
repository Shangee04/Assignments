import json
f = open("sample_data.json")
data = json.load(f)
my_list = []
for i in data["parametersList"]:
    dict = {"parameterName": i["parameterName"],
            "min": i["min"],
            "max": i["max"],
            "avg": i["avg"]}
    my_list.append(dict)
    print(my_list)

