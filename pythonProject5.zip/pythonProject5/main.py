from fastapi import FastAPI
import uvicorn
from scripts.core.services.service_item import app as items_inventory

app_main = FastAPI()
app_main.include_router(items_inventory)

if __name__ == "__main__":
    uvicorn.run("main:app_main")

