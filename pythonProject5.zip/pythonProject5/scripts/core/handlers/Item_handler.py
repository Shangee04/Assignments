from schemas.models import Item
from utility.mong_utility import inventory


def read_item():
    return {"Welcome to Inventory"}


def get_all():
    try:
        items = (inventory.find())
        new_item = []
        for product in items:
            del product["_id"]
            new_item.append(product)
        return new_item
    except Exception as e:
        return "error", str(e)


def create_item(item: Item):
    try:
        inventory.insert_one(item.dict())
        return {"created"}
    except Exception as es:
        return {"not expected output came", str(es)}


def update_item(name: str, upd: Item):
    inventory.update_one({"name": name}, {"$set": upd.dict()})
    return {"updated"}


def delete_item(name: str):
    inventory.delete_one({"name": name})
    return {"deleted"}


def pipeline_aggregate():
    pipeline = [
    {
        '$addFields': {
            'Total_price': {
                '$multiply': [
                    '$quantity', '$cost'
                ]
            }
        }
    }, {
        '$group': {
            '_id': None,
            'sum_of_all_price': {
                '$sum': '$Total_price'
            }
        }
    }, {
        '$project': {
            '_id': 0
        }
    }
]
    data = inventory.aggregate(pipeline)
    data = list(data)
    print(data)
    return {"Total_price": data[0]['sum_of_all_price']}



